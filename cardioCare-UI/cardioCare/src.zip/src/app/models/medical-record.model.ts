export interface MedicalRecord {
  id: number;
  fecha: string;        // ISO string
  diagnostico: string;
  notas: string;
}
