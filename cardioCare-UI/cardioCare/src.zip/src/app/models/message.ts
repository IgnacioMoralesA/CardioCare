export interface Message {
  id: number;
  content: string;
  sender: string;
  sentAt: string;
  tag: string;
}
