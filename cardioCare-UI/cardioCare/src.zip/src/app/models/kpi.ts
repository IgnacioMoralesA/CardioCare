export interface KPIResponse {
  pacientesActivos: number;
  consultasPendientes: number;
  satisfaccion: number;
  alertasCriticas: number;
}
