export interface Report {
  id: number;
  rut: string;
  nombre: string;
  apellido: string;
  edad: number;
  prioridad: string;
}
