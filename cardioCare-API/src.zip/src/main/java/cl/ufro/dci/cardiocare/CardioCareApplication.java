package cl.ufro.dci.cardiocare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardioCareApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardioCareApplication.class, args);
    }

}
